<style>
#wpfooter{
	padding:30px 20px;
}
</style>
<div id="wpfooter" >
		<p>&nbsp;</p>
		<p class="alignleft" id="footer-left" style='margin-left:-30px !important;'>
		&copy; <a href="http://wapppress.com/" target="_blank">wapppress.com</a>, <?php echo date('Y'); ?>. Unauthorized use and/or duplication of this plugin without express and written permission from this plugin's author and/or owner is strictly prohibited. A WappPress plugin can only be used for one wordpress website. If you want to  use it on second website, you have to purchase another license.</p>
	
		<p>&nbsp;</p>
		<p>&nbsp;</p>
	<div class="clear"></div>
</div>

</body>
</html>