=== Plugin Name ===
Contributors: wapppress
Tags: android app, mobile app
Requires at least: 3.0.1
Tested up to: 5.0.1
Stable tag: 5.3

== Installation ==

1. You can install this plugin using standard Wordpress procedure
2. Activate the plugin through the 'Plugins' menu in WordPress
